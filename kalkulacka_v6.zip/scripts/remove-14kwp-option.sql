-- Remove the 14 kWp option from pricing table
DELETE FROM pricing WHERE item_name = '14 kWp - pro velké domy';
